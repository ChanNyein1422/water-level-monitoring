#include <Arduino.h>
#include <TensorFlowLite_ESP32.h>
#include "tensorflow/lite/micro/all_ops_resolver.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/micro_error_reporter.h"
#include "tensorflow/lite/schema/schema_generated.h"
#include <ESP32Servo.h>
#include "water_level_model.h"  // xxd’d TFLM model

// HC‑SR04 pins & timing
#define TRIG_PIN     13
#define ECHO_PIN     12
#define MAX_DISTANCE 400    // cm
#define TIMEOUT_US   (MAX_DISTANCE * 58UL)

// Servo pins
#define SERVO_EXIT_PIN  26   // drain pump
#define SERVO_ENTRY_PIN 27   // fill pump

// TFLM arena
constexpr int kTensorArenaSize = 8 * 1024;
static uint8_t tensor_arena[kTensorArenaSize] __attribute__((aligned(16)));

static tflite::MicroErrorReporter micro_error_reporter;
static tflite::AllOpsResolver     resolver;
static tflite::MicroInterpreter*   interpreter  = nullptr;
static TfLiteTensor*               model_input  = nullptr;
static TfLiteTensor*               model_output = nullptr;

// StandardScaler parameters from training
const float mean_vals[15] = {
  10.23747, 12.78680, 15.36960, 12.79627, 10.12873,
  12.62947, 12.51013, 12.44013,  9.83120,  9.78467,
   9.85513, 17.65013,  9.69593, 10.74487, 12.29913
};
const float scale_vals[15] = {
   3.81956, 31.92771, 44.83161, 31.85328,  2.80043,
  31.84079, 31.84651, 31.85314,  2.69988,  2.62611,
   2.97515, 54.70596,  3.90685, 12.47535, 32.13457
};

Servo servoExit;  // drain‑water servo
Servo servoEntry; // fill‑water servo

float readHC_SR04() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  unsigned long dur = pulseIn(ECHO_PIN, HIGH, TIMEOUT_US);
  return (dur == 0) ? float(MAX_DISTANCE)
                    : float(dur) / 58.0f;
}

void setup() {
  Serial.begin(115200);

  // ultrasonic pins
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  // attach servos and start closed (0°)
  servoExit.attach(SERVO_EXIT_PIN);
  servoEntry.attach(SERVO_ENTRY_PIN);
  servoExit.write(0);
  servoEntry.write(0);

  // --- TFLM initialization ---
  const tflite::Model* model = tflite::GetModel(water_level_model_tflite);
  if (model->version() != TFLITE_SCHEMA_VERSION) {
    Serial.println("Model schema mismatch!");
    while (1);
  }

  static tflite::MicroInterpreter static_interpreter(
    model, resolver, tensor_arena, kTensorArenaSize, &micro_error_reporter
  );
  interpreter  = &static_interpreter;
  if (interpreter->AllocateTensors() != kTfLiteOk) {
    Serial.println("Tensor allocation failed");
    while (1);
  }
  model_input  = interpreter->input(0);
  model_output = interpreter->output(0);

  Serial.println("Setup complete\n");
}

void loop() {
  const int N = 15;

  // 1) Collect & normalize readings
  Serial.println(F("Collected readings (cm → norm):"));
  for (int i = 0; i < N; i++) {
    float cm = readHC_SR04();
    float norm = 0.0f;
    if (scale_vals[i] != 0.0f) {
      norm = (cm - mean_vals[i]) / scale_vals[i];
    }
    model_input->data.f[i] = norm;
    Serial.printf(" [%2d] %6.2f cm → %8.5f norm\n", i, cm, norm);
    delay(200);
  }

  // 2) Run inference
  if (interpreter->Invoke() != kTfLiteOk) {
    Serial.println("Inference failed");
    return;
  }

  // 3) Print all class scores
  int C = model_output->dims->data[1];
  Serial.println(F("\nInference scores:"));
  for (int i = 0; i < C; i++) {
    float score = model_output->data.f[i];
    Serial.printf("  Class %d: %.6f\n", i, score);
  }

  // 4) Pick best class
  int bestI = 0;
  float bestS = model_output->data.f[0];
  for (int i = 1; i < C; i++) {
    float s = model_output->data.f[i];
    if (s > bestS) {
      bestS = s;
      bestI = i;
    }
  }

  // 5) Servo logic
  // 0=A1 Fast Rise → drain 100%
  // 1=A2 Slow Rise → drain 50%
  // 2=A3 Fast Fall → fill 100%
  // 3=A4 Slow Fall → fill 50%
  // 4=A5 Stable → both 0%
  switch (bestI) {
    case 0:
      servoExit.write(180);
      servoEntry.write(0);
      break;
    case 1:
      servoExit.write(90);
      servoEntry.write(0);
      break;
    case 2:
      servoExit.write(0);
      servoEntry.write(180);
      break;
    case 3:
      servoExit.write(0);
      servoEntry.write(90);
      break;
    default:
      servoExit.write(0);
      servoEntry.write(0);
  }

  // 6) Final debug print
  static const char* labels[] = {
    "A1 Fast Rise", "A2 Slow Rise",
    "A3 Fast Fall", "A4 Slow Fall",
    "A5 Stable"
  };
  Serial.printf("\n→ Predicted: %s (%.6f)\n\n", labels[bestI], bestS);

  delay(1000);
}
